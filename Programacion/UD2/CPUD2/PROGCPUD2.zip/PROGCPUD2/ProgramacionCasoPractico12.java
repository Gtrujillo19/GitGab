
public class ProgramacionCasoPractico12 {

	public static void main(String[] args) {

		// Declaracion variables Tipo de dato / Espacio en la memoria numero

		int numero = 10;

		// Uso del bucle while para la ordenación

		while (numero >= 1) {
			System.out.println(numero);

			// Cada vez que el programa imprima un número, también debe restarle 1.
			numero--;
		}
	}
}
